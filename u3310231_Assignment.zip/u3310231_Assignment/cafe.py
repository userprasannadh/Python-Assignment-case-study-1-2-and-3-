# Name:Prasanna Adhikari
# Student ID: u3310231
# Date: September 17, 2025

menu = {
    "Coffee": 3.50,
    "Tea": 2.50,
    "Muffin": 4.00,
    "Sandwich": 6.50,
    "Juice": 3.00,
    "Salad": 5.50
}

def show_menu():
    print("\n=== Café Menu ===")
    for item, price in menu.items():
        print(f"{item} - ${price:.2f}")

def checkout():
    show_menu()
    choice = input("\nWhat would you like to order? ").title()
    if choice not in menu:
        print("Sorry, that item is not available.")
        return
    price = menu[choice]
    tax = price * 0.10
    student = input("Are you a student? (y/n): ").lower()
    discount = (price + tax) * 0.05 if student == "y" else 0
    total = price + tax - discount

    print("\n=== Receipt ===")
    print(f"Item: {choice} - ${price:.2f}")
    print(f"Tax (10%): ${tax:.2f}")
    print(f"Discount: -${discount:.2f}")
    print(f"Total: ${total:.2f}")

def main():
    print("Welcome to Campus Café!")
    checkout()
    print("\nThank you, have a nice day!")

if __name__ == "__main__":
    main()

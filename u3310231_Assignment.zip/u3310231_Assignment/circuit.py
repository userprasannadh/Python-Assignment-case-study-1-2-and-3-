# Name: Prasanna Adhikari
# Student ID: u3310231
# Date: September 17, 2025

def circuit_a(A, B, C):
    # Step a
    a = not A
    # Step b
    b = not C
    # Step c
    c = not (a and b)
    # Step d
    d = not C
    # Step e
    e = c and d
    # Step f
    f = A and B and C
    # Step g (Final output X)
    X = e or f
    return int(X)

def circuit_b(A, B, C):
    # Step h
    h = not B
    # Step i
    i = h or C
    # Step j (Final output Y)
    Y = A and i
    return int(Y)

# Truth table test
print("A B C | X (circuit a) | Y (circuit b)")
for A in [0,1]:
    for B in [0,1]:
        for C in [0,1]:
            X = circuit_a(bool(A), bool(B), bool(C))
            Y = circuit_b(bool(A), bool(B), bool(C))
            print(f"{A} {B} {C} | {X}           | {Y}")

# Name: Prasanna Adhikari
# Student ID: u3310231# Boolean Circuit Simulation
# Case Study 3

def circuit_a(A, B, C):
    # Step a
    a = not A
    # Step b
    b = not C
    # Step c
    c = not (a and b)
    # Step d
    d = not C
    # Step e
    e = c and d
    # Step f
    f = A and B and C
    # Step g (Final output X)
    X = e or f
    return int(X)

def circuit_b(A, B, C):
    # Step h
    h = not B
    # Step i
    i = h or C
    # Step j (Final output Y)
    Y = A and i
    return int(Y)

# Truth table test
print("A B C | X (circuit a) | Y (circuit b)")
for A in [0,1]:
    for B in [0,1]:
        for C in [0,1]:
            X = circuit_a(bool(A), bool(B), bool(C))
            Y = circuit_b(bool(A), bool(B), bool(C))
            print(f"{A} {B} {C} | {X}           | {Y}")

# Date: September 17, 2025

room_state = {"projector_on": False, "capacity": 3, "topic": ""}
attendance = set()
temperatures = []

def toggle_projector():
    room_state["projector_on"] = not room_state["projector_on"]
    print("Projector is now", "ON" if room_state["projector_on"] else "OFF")

def set_topic():
    room_state["topic"] = input("Enter topic: ").strip()
    print("Topic set to:", room_state["topic"])

def add_student():
    if len(attendance) >= room_state["capacity"]:
        print("ROOM FULL!")
    else:
        name = input("Enter student name: ").title()
        attendance.add(name)
        print(f"{name} added. ({len(attendance)}/{room_state['capacity']})")

def remove_student():
    name = input("Enter student to remove: ").title()
    if name in attendance:
        attendance.remove(name)
        print(f"{name} removed.")
    else:
        print("Not found.")

def add_temp():
    try:
        t = float(input("Enter temperature (°C): "))
        temperatures.append(t)
        if t < 16 or t > 28:
            print("⚠ WARNING: Temperature out of range!")
    except:
        print("Invalid input.")

def stats():
    if temperatures:
        print(f"Min: {min(temperatures):.1f}, Max: {max(temperatures):.1f}, Avg: {sum(temperatures)/len(temperatures):.1f}")
    else:
        print("No data yet.")

def report():
    print("\n=== Classroom Report ===")
    print("Projector:", "ON" if room_state["projector_on"] else "OFF")
    print("Topic:", room_state["topic"] or "Not set")
    print(f"Attendance ({len(attendance)}/{room_state['capacity']}): {', '.join(attendance) if attendance else 'None'}")
    stats()

def main():
    while True:
        print("\n1. Toggle Projector\n2. Set Topic\n3. Add Student\n4. Remove Student\n5. Add Temp\n6. Show Stats\n7. Report\n8. Exit")
        c = input("Choose: ")
        if c == "1": toggle_projector()
        elif c == "2": set_topic()
        elif c == "3": add_student()
        elif c == "4": remove_student()
        elif c == "5": add_temp()
        elif c == "6": stats()
        elif c == "7": report()
        elif c == "8":
            if room_state["topic"] and not room_state["projector_on"]:
                print("Reminder: Topic set but projector is OFF!")
            print("Goodbye.")
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()
